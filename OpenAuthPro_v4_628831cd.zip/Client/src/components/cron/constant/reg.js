export const
  NUMBER = /^[0-9]+$/
