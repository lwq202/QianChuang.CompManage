// 性别
export const sexList: Array<any> = [
  {
    Value: 'Male',
    Text: "男"
  },
  {
    Value: 'Female',
    Text: "女"
  }
];

// 是否
export const whether: Array<any> = [
  {
    Value: true,
    Text: "是"
  },
  {
    Value: false,
    Text: "否"
  }
];
